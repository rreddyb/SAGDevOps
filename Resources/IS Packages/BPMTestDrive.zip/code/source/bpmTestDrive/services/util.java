package bpmTestDrive.services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-05-15 09:04:31 UTC
// -----( ON-HOST: sagbase

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getNextMonday (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNextMonday)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] object:0:required nextMonday
		Calendar now = Calendar.getInstance();  
		int weekday = now.get(Calendar.DAY_OF_WEEK);  
		if (weekday != Calendar.MONDAY)  
		{  
		    // calculate how much to add  
		    // the 2 is the difference between Saturday and Monday  
		    int days = (Calendar.SATURDAY - weekday + 2) % 7;  
		    now.add(Calendar.DAY_OF_YEAR, days);  
		}  
		// now is the date you want
		now.set(Calendar.HOUR, 9);
		now.set(Calendar.MINUTE, 0);
		now.set(Calendar.SECOND, 0);
		now.set(Calendar.AM_PM, Calendar.AM);
		
		Date NextMonday = now.getTime();
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "nextMonday", NextMonday );
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void sleep (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleep)>> ---
		// @sigtype java 3.5
		// [i] field:0:required seconds
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	seconds = IDataUtil.getString( pipelineCursor, "seconds" );
			long s = Long.parseLong(seconds);
			try {
				Thread.sleep(s*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}			
		pipelineCursor.destroy();
		
		// pipeline
		
			
		// --- <<IS-END>> ---

                
	}
}

