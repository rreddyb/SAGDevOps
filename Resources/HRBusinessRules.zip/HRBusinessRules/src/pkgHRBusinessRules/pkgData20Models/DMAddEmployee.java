package pkgHRBusinessRules.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="HRBusinessRules",DataModelName="AddEmployee",EventTypeName="") public class DMAddEmployee extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotName;
  private String slotAddress;
  private String slotCityStateZip;
  private String slotTitle;
  private Integer slotYearsOfExperience;
  private Integer slotSalary;
  private String slotAssignedOffice;
  private String slotTrainingDate;
  private String slotComputerType;
  private DMpub_publish_envelope slot_env;
  @IDataAnnotation(OriginalFieldName="Name",FieldName="slotName",SlotKey="/Name;1;0",Position=0,CameFromFloat=false) public String getSlotName(){
    return this.slotName;
  }
  @IDataAnnotation(OriginalFieldName="Name",FieldName="slotName",SlotKey="/Name;1;0",Position=0,CameFromFloat=false) public void setSlotName(  String paramName){
    this.slotName=paramName;
  }
  @IDataAnnotation(OriginalFieldName="Address",FieldName="slotAddress",SlotKey="/Address;1;0",Position=1,CameFromFloat=false) public String getSlotAddress(){
    return this.slotAddress;
  }
  @IDataAnnotation(OriginalFieldName="Address",FieldName="slotAddress",SlotKey="/Address;1;0",Position=1,CameFromFloat=false) public void setSlotAddress(  String paramAddress){
    this.slotAddress=paramAddress;
  }
  @IDataAnnotation(OriginalFieldName="CityStateZip",FieldName="slotCityStateZip",SlotKey="/CityStateZip;1;0",Position=2,CameFromFloat=false) public String getSlotCityStateZip(){
    return this.slotCityStateZip;
  }
  @IDataAnnotation(OriginalFieldName="CityStateZip",FieldName="slotCityStateZip",SlotKey="/CityStateZip;1;0",Position=2,CameFromFloat=false) public void setSlotCityStateZip(  String paramCityStateZip){
    this.slotCityStateZip=paramCityStateZip;
  }
  @IDataAnnotation(OriginalFieldName="Title",FieldName="slotTitle",SlotKey="/Title;1;0",Position=3,CameFromFloat=false) public String getSlotTitle(){
    return this.slotTitle;
  }
  @IDataAnnotation(OriginalFieldName="Title",FieldName="slotTitle",SlotKey="/Title;1;0",Position=3,CameFromFloat=false) public void setSlotTitle(  String paramTitle){
    this.slotTitle=paramTitle;
  }
  @IDataAnnotation(OriginalFieldName="YearsOfExperience",FieldName="slotYearsOfExperience",SlotKey="/YearsOfExperience;3.6;0",Position=4,CameFromFloat=false) public Integer getSlotYearsOfExperience(){
    return this.slotYearsOfExperience;
  }
  @IDataAnnotation(OriginalFieldName="YearsOfExperience",FieldName="slotYearsOfExperience",SlotKey="/YearsOfExperience;3.6;0",Position=4,CameFromFloat=false) public void setSlotYearsOfExperience(  Integer paramYearsOfExperience){
    this.slotYearsOfExperience=paramYearsOfExperience;
  }
  @IDataAnnotation(OriginalFieldName="YearsOfExperience",FieldName="slotYearsOfExperience",SlotKey="/YearsOfExperience;3.6;0",Position=4,CameFromFloat=false) public void setSlotYearsOfExperience(  String paramYearsOfExperience){
    if (paramYearsOfExperience != null) {
      this.slotYearsOfExperience=new Integer(paramYearsOfExperience);
    }
 else {
      this.slotYearsOfExperience=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="YearsOfExperience",FieldName="slotYearsOfExperience",SlotKey="/YearsOfExperience;3.6;0",Position=4,CameFromFloat=false) public void setSlotYearsOfExperience(  Double paramYearsOfExperience){
    if (paramYearsOfExperience != null) {
      this.slotYearsOfExperience=paramYearsOfExperience.intValue();
    }
 else {
      this.slotYearsOfExperience=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Salary",FieldName="slotSalary",SlotKey="/Salary;3.6;0",Position=5,CameFromFloat=false) public Integer getSlotSalary(){
    return this.slotSalary;
  }
  @IDataAnnotation(OriginalFieldName="Salary",FieldName="slotSalary",SlotKey="/Salary;3.6;0",Position=5,CameFromFloat=false) public void setSlotSalary(  Integer paramSalary){
    this.slotSalary=paramSalary;
  }
  @IDataAnnotation(OriginalFieldName="Salary",FieldName="slotSalary",SlotKey="/Salary;3.6;0",Position=5,CameFromFloat=false) public void setSlotSalary(  String paramSalary){
    if (paramSalary != null) {
      this.slotSalary=new Integer(paramSalary);
    }
 else {
      this.slotSalary=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Salary",FieldName="slotSalary",SlotKey="/Salary;3.6;0",Position=5,CameFromFloat=false) public void setSlotSalary(  Double paramSalary){
    if (paramSalary != null) {
      this.slotSalary=paramSalary.intValue();
    }
 else {
      this.slotSalary=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AssignedOffice",FieldName="slotAssignedOffice",SlotKey="/AssignedOffice;1;0",Position=6,CameFromFloat=false) public String getSlotAssignedOffice(){
    return this.slotAssignedOffice;
  }
  @IDataAnnotation(OriginalFieldName="AssignedOffice",FieldName="slotAssignedOffice",SlotKey="/AssignedOffice;1;0",Position=6,CameFromFloat=false) public void setSlotAssignedOffice(  String paramAssignedOffice){
    this.slotAssignedOffice=paramAssignedOffice;
  }
  @IDataAnnotation(OriginalFieldName="TrainingDate",FieldName="slotTrainingDate",SlotKey="/TrainingDate;1;0",Position=7,CameFromFloat=false) public String getSlotTrainingDate(){
    return this.slotTrainingDate;
  }
  @IDataAnnotation(OriginalFieldName="TrainingDate",FieldName="slotTrainingDate",SlotKey="/TrainingDate;1;0",Position=7,CameFromFloat=false) public void setSlotTrainingDate(  String paramTrainingDate){
    this.slotTrainingDate=paramTrainingDate;
  }
  @IDataAnnotation(OriginalFieldName="ComputerType",FieldName="slotComputerType",SlotKey="/ComputerType;1;0",Position=8,CameFromFloat=false) public String getSlotComputerType(){
    return this.slotComputerType;
  }
  @IDataAnnotation(OriginalFieldName="ComputerType",FieldName="slotComputerType",SlotKey="/ComputerType;1;0",Position=8,CameFromFloat=false) public void setSlotComputerType(  String paramComputerType){
    this.slotComputerType=paramComputerType;
  }
  @IDataAnnotation(OriginalFieldName="_env",FieldName="slot_env",SlotKey="/_env;4;0;pub.publish:envelope",Position=9,CameFromFloat=false) public DMpub_publish_envelope getSlot_env(){
    return this.slot_env;
  }
  @IDataAnnotation(OriginalFieldName="_env",FieldName="slot_env",SlotKey="/_env;4;0;pub.publish:envelope",Position=9,CameFromFloat=false) public void setSlot_env(  DMpub_publish_envelope param_env){
    this.slot_env=param_env;
  }
}
