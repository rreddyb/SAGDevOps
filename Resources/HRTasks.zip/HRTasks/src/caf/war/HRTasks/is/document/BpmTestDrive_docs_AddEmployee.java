package caf.war.HRTasks.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class BpmTestDrive_docs_AddEmployee extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "bpmTestDrive.docs:AddEmployee";
	// Used by Designer to access the source document.
	@SuppressWarnings("unused")
	private static final String DOCUMENT_SRC = "http://localhost:5555";
	private java.lang.String name;
	private java.lang.String address;
	private java.lang.String cityStateZip;
	private java.lang.String title;
	private int yearsOfExperience;
	private int salary;
	private java.lang.String assignedOffice;
	private java.lang.String trainingDate;
	public static String[][] FIELD_NAMES = new String[][] {{"name", "Name"},{"address", "Address"},{"cityStateZip", "CityStateZip"},{"title", "Title"},{"yearsOfExperience", "YearsOfExperience"},{"salary", "Salary"},{"assignedOffice", "AssignedOffice"},{"trainingDate", "TrainingDate"},{"computerType", "ComputerType"},
	};
	private java.lang.String computerType;
	

	public BpmTestDrive_docs_AddEmployee() {
	}


	public java.lang.String getName()  {
		
		return name;
	}


	public void setName(java.lang.String name)  {
		this.name = name;
	}


	public java.lang.String getAddress()  {
		
		return address;
	}


	public void setAddress(java.lang.String address)  {
		this.address = address;
	}


	public java.lang.String getCityStateZip()  {
		
		return cityStateZip;
	}


	public void setCityStateZip(java.lang.String cityStateZip)  {
		this.cityStateZip = cityStateZip;
	}


	public java.lang.String getTitle()  {
		
		return title;
	}


	public void setTitle(java.lang.String title)  {
		this.title = title;
	}


	public int getYearsOfExperience()  {
		
		return yearsOfExperience;
	}


	public void setYearsOfExperience(int yearsOfExperience)  {
		this.yearsOfExperience = yearsOfExperience;
	}


	public int getSalary()  {
		
		return salary;
	}


	public void setSalary(int salary)  {
		this.salary = salary;
	}


	public java.lang.String getAssignedOffice()  {
		
		return assignedOffice;
	}


	public void setAssignedOffice(java.lang.String assignedOffice)  {
		this.assignedOffice = assignedOffice;
	}


	public java.lang.String getTrainingDate()  {
		
		return trainingDate;
	}


	public void setTrainingDate(java.lang.String trainingDate)  {
		this.trainingDate = trainingDate;
	}


	public java.lang.String getComputerType()  {
		
		return computerType;
	}


	public void setComputerType(java.lang.String computerType)  {
		this.computerType = computerType;
	}

}