package caf.war.HRTasks.reviewempdatainboxresults;


/**
 * Task Search bean for 'ReviewEmpData' task.
 */
public class ReviewEmpDataSearchProvider extends com.webmethods.caf.faces.data.task.impl.TaskInboxSearchContentProvider {

	private static final long serialVersionUID = 1182504823735336960L;
	private static final String TASK_TYPE_ID = "8C638F31-7734-5F2A-A979-FFF72CD0AEFE";

	public ReviewEmpDataSearchProvider() {
		super(); // task type id to search
		m_searchQuery = new CustomInboxSearchQuery(); 
	}

	/**
	 * Typed ITaskData getter
	 * @return current task data
	 */
	public com.webmethods.caf.taskclient.ReviewEmpData.TaskData getTaskData() {
		return (com.webmethods.caf.taskclient.ReviewEmpData.TaskData)getValue(PROPERTY_TASKDATA);
	}

	/**
	 * Typed custom search query
	 */
	public CustomInboxSearchQuery getSearchQuery() {  
		return (CustomInboxSearchQuery)m_searchQuery;
	}

	/**
	 * Custom inbox search query that can be extended
	 **/
	public class CustomInboxSearchQuery extends com.webmethods.caf.faces.data.task.impl.TaskInboxSearchContentProvider.InboxSearchQuery {
		private static final long serialVersionUID = 6347489825562607616L;
		
		public CustomInboxSearchQuery() {
			super();
		}

	}				

}
