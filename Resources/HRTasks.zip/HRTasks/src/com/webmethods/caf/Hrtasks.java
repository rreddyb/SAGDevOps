/**
 * 
 */
package com.webmethods.caf;

/**
 * @author Administrator
 *
 */
public class Hrtasks extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public Hrtasks()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "HRTasks" );
	}
}