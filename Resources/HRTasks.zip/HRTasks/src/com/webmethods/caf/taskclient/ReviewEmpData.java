package com.webmethods.caf.taskclient;


import com.webmethods.caf.faces.data.task.ITaskData;
import com.webmethods.caf.faces.data.ContentProviderException;

/**
 * Task Client bean for 'ReviewEmpData' task.
 */
public class ReviewEmpData extends com.webmethods.caf.faces.data.task.impl.TaskContentProviderExtended {

	private static final long serialVersionUID = 2560741928262952960L;
	
	/**
	 * Globally unique task type id
	 */
	private static final String TASK_TYPE_ID = "8C638F31-7734-5F2A-A979-FFF72CD0AEFE";

	/**
	 * Default constructor
	 */
	public ReviewEmpData() {
		super();
		setTaskTypeID(TASK_TYPE_ID);
	}
	
	/**
	 * Task Data Object
	 */
	public static class TaskData extends com.webmethods.caf.faces.data.task.impl.TaskData {

		private static final long serialVersionUID = 4865481322314452992L;
		
		public static String[][] FIELD_NAMES = new String[][] {{"addEmployee", "AddEmployee"},
		};

		private caf.war.HRTasks.is.document.BpmTestDrive_docs_AddEmployee addEmployee = null;

		public static final String[] INPUTS = new String[] {"addEmployee", };

		public static final String[] OUTPUTS = new String[] {"addEmployee", };

		public TaskData() {
		}

		public caf.war.HRTasks.is.document.BpmTestDrive_docs_AddEmployee getAddEmployee()  {
			if (addEmployee == null) {
				addEmployee = new caf.war.HRTasks.is.document.BpmTestDrive_docs_AddEmployee();
			}
			return addEmployee;
		}

		public void setAddEmployee(caf.war.HRTasks.is.document.BpmTestDrive_docs_AddEmployee addEmployee)  {
			this.addEmployee = addEmployee;
		}
		
	}
	
	/**
	 * Return current task data object
	 * @return current task data
	 */
	public TaskData getTaskData() {
		return (TaskData)getValue(PROPERTY_KEY_TASKDATA);
	}

	/**
	 * Creates new task data object
	 * @return newly created task data object
	 */	
	protected ITaskData newTaskData() throws ContentProviderException {
		return new TaskData();
	}

}